let http = require("http");
let path = require("path");
let express = require("express");
let cors = require("cors");
const bodyParser = require("body-parser");
const connectDB = require("./db/connectDB");
const routes = require("./routes");
let app = express();

app.use(
  cors({
    origin: "*",
  })
);
//body parser
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());

//routes
app.use("/v1", routes);

//database connection
connectDB();

http.createServer(app).listen(3001, () => {
  console.log("server started");
});
