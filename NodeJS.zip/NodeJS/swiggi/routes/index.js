let express = require("express");
let routes = express.Router();
const user = require("../models/user.model");
const dish = require("../models/dish.model")

let userRoute = require("./user.route")
let dishRoute = require("./dish.route")

routes.use("/user",userRoute)
routes.use("/dish",dishRoute)

module.exports = routes;
