let mongoose = require("mongoose")

let billSchema = new mongoose.Schema({
    mobileNo : {
        type : String,
        required : true,
    },

    amount : {
        type : Number,
        required : true,
    }
})

let bill = mongoose.model("billSchema",billSchema)
module.exports = bill