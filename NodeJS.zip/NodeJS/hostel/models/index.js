module.exports.studentSchema = require("./student.model")
module.exports.feeSchema = require("./fee.model")
module.exports.trusteeSchema = require("./trustee.model")