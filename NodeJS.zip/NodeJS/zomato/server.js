var http = require("http")
var path = require("path")
var express = require("express")
var cors = require("cors")
const bodyParser = require("body-parser")
const connectDB = require("./db/connectDB");
const exp = require("constants")
const route = require("./routes/user.route")
const routes = require("./routes")
let app = express();

app.use(express.json())
app.use(
    cors({
        origin:"*"
    })
)
//body parser
app.use(bodyParser.urlencoded({extended:false}))


//routes
app.use("/v2",routes);
// app.use("/v3",routes)

// database connection
connectDB()

http.createServer(app).listen(3242,()=>{
    console.log("server started");
})
