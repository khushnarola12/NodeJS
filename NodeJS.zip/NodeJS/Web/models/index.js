module.exports.userSchema = require("./user.model");
module.exports.productSchema = require("./product.model");
module.exports.orderSchema = require("./order.model");
