var http = require("http");
var path = require("path");
var express= require("express");
var cors = require("cors");
const connectDB = require("./db/connectDB")
const bodyParser = require("body-parser")
const { connect } = require("net");
const routes = require("./routes");
var app = express()


app.use(express.json())
app.use(
    cors({
        origin:"*"
    })
)
app.use(bodyParser.urlencoded({extended:false}))
app.use("/v4",routes)

//database connectivity
connectDB()

http.createServer(app).listen(2332,()=>{
    console.log("server started");
})