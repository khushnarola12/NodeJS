let mongoose = require("mongoose")

let connectDB = () =>
{
     mongoose
     .connect("mongodb://localhost:27017/swiggi")
     .then(()=>{
        console.log("database connected");
     })
     .catch((err)=>{
        console.log(err);
     });
};

module.exports = connectDB;