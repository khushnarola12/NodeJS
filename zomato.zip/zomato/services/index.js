module.exports.userService  = require("./user.service")
module.exports.itemService = require("./item.service")
module.exports.staffservice = require("./staff.service")
module.exports.billservice = require("./bill.service")