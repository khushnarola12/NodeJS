const {dishService} = require("../services")

let addDish = async(req,res)=>{
    let dish = req.body
    console.log(dish);

    let result = await dishService.addDish(dish)
    result

    res.status(201).json({
        message : "dish added successfully",
        result
    })
}

let getDish = async(req,res) =>{
    let result = await dishService.getDish()

    res.status(200).json({
        message : "dish got successfully",
        result
    })
}

let cateDish = async(req,res) =>{
    let result = await dishService.cateDish()

    res.status(200).json({
        message : "dish get successfully",
        result
    })
}

let update = async(req,res)=>{
    let body=req.body
    let {id} = req.params
    
    let dish = await dishService.update(id,body)

    res.status(200).json({
        message :"dish updated successfully",
        dish
    })
}

module.exports = {addDish,getDish,cateDish,update}