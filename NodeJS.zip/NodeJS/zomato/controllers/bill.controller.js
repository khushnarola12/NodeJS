const {billservice} = require("../services")

let createBill = async(req,res) =>{
    let bill = req.body
    console.log(bill);

    let result = await billservice.createBill(bill)
    console.log(result);

    res.status(201).json({
        message:"bill gereated successfully",
        result
    })

}

let getBill = async (req,res)=>{
    let result = await billservice.getBill();

    res.status(200).json({
        message:"bill printed successfully",
        result
    })
}

module.exports = {createBill,getBill}