module.exports.userSchema = require("./user.model")
module.exports.movieSchema = require("./movie.model")