const sendEmail = require("../middleware/sendMail");
const user = require("../models/user.model");
const { userService } = require("../services");

let register = async (req, res) => {
  let user = req.body;
  console.log(user);

  let result = await userService.register(user);
  console.log(result);

  if (result) {
    sendEmail(user.email, "welcome to zomato", "thanks for using zomato");
  }

  res.status(201).json({
    messsage: "user created successfully",
    result,
  });
};

let getuser = async (req, res) => {
  let result = await userService.getAlluser();

  res.status(200).json({
    messsage: "user get successfully",
    result,
  });
};

let remove = async (req, res) => {
  let { id } = req.params;

  let user = await userService.remove(id);

  res.status(200).json({
    messsage: "user deleted successfully",
    user,
  });
};

let login = async (req, res) => {
  let user = req.body;
  let email = user.email;
  console.log(email);

  let result = await userService.login(email);
  // let body = result.body

  if (result) {
    if (user.password === result.password) {
      res.status(200).json({
        messsage: "you logged in successfully",
        result,
      });
    } else {
      res.status(200).json({
        messsage: "password invalid",
      });
    }
  } else {
    res.status(404).json({ message: "user not found" });
  }
};

module.exports = { register, getuser, remove, login };
