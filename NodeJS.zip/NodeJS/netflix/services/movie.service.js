const {movieSchema}=require("../models")


let addMovie = (Movie) => {
    return movieSchema.create(Movie);

}

let getMovie = () =>{
    return movieSchema.find();
}

let getThriller = ()=>{
    let category =  movieSchema.find({category:"Thriller"})
    return category
}

let update = (id,body) =>{
    return movieSchema.findByIdAndUpdate(id,body)
}
module.exports = {addMovie,getMovie,getThriller,update}
