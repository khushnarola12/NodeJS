let http = require("http");

http
  .createServer((req, res) => {
    console.log("server start");
    console.log(req.url);

    res.end("Hello");
  })
  .listen(3001, () => {
    console.log("server started");
  });
