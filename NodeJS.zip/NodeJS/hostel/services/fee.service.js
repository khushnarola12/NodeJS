const {feeSchema} = require("../models")
const fee = require("../models/fee.model")

let payFee = (fee)=>{
    return feeSchema.create(fee)
}

let get = () =>{
    return feeSchema.find()
}

let deleteFee = (id)=>{
    return feeSchema.findByIdAndDelete(id)
}


module.exports = {payFee,get,deleteFee}