const {itemService} = require("../services")

let addItem = async(req,res) =>{
    let item = req.body
    console.log(item);

    let result = await itemService.addItem(item)
    console.log(result);

    res.status(201).json({
        message : "item added successfully",
        result
    })

}

let getItem = async(req,res) =>{
    let result = await itemService.getItem();

    res.status(200).json({
        message : "item got successfully",
        result
    })
}

let update = async(req,res) =>{
    let body = req.body
    let {id} =req.params

    let item = await itemService.update(id,body)

    res.status(200).json({
        message :"item updated successfully",
        item
    })

}

module.exports = {addItem,getItem,update}