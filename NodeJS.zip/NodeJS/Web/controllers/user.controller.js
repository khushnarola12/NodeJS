const sendEmail = require("../middleware/sendMail");
const { userService } = require("../services");

let register = async (req, res) => {
  let user = req.body;

  console.log(user);

  let result = await userService.register(user);
  console.log(result);

  // if (result) {
  //   sendEmail(user.email, "Testing Email", "Hello user");
  // }

  res.status(201).json({
    message: "user created successfully",
    result,
  });
};

let getUser = async (req, res) => {
  let result = await userService.getAllUser();

  res.status(200).json({
    message: "user get successfully",
    result,
  });
};

let deleteUser = async (req, res) => {
  // console.log(req.params);
  let { id } = req.params;

  let user = await userService.deleteUser(id);

  res.status(200).json({
    message: "user deleted success",
    user,
  });
};

let updateUser = async (req, res) => {
  console.log(req.params);
  console.log(req.body);

  let { id } = req.params;
  let body = req.body;

  let user = await userService.updateUser(id, body);

  res.status(200).json({
    message: "user updated success",
    user,
  });
};

module.exports = { register, getUser, deleteUser, updateUser };
