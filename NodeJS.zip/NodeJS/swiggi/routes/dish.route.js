const {dishController} = require("../controllers")
let express = require("express")
let route = express.Router()


route.post("/add",dishController.addDish)
route.get("/get",dishController.getDish)
route.get("/cate",dishController.cateDish)
route.put("/update/:id",dishController.update)

module.exports = route