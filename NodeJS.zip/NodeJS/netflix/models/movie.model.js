let mongoose = require("mongoose")

let movieSchema = new mongoose.Schema({
    movieName: {
        type:String,
        required:true
    } ,

    category :{
        type :String,
        required : true,
    }
    
})

let movie = mongoose.model("movieSchema",movieSchema);
module.exports = movie