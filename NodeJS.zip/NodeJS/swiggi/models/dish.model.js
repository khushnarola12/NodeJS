let mongoose = require("mongoose")

let dishSchema = new mongoose.Schema({
    dishName : {
        type : String,
        required : true
    },

    category :{
        type : String,
        required : true
    }
})

let dish = mongoose.model("dishSchema",dishSchema)
module.exports = dish