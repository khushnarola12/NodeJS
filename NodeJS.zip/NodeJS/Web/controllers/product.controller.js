const {productService} = require("../services")

let addProduct = async(req,res) =>{
    let product = req.body
    console.log(product);

    let result = await productService.addProduct(product)
 
    res.status(201).json({
        message : "product added successfully",
        result
    })
}

let getProduct = async(req,res) =>{
    let result = await productService.getProduct()

    res.status(200).json({
        message : "product get successfully",
        result
    })

}

let deleteProduct = async(req,res) =>{
    let {id} = req.params

    let product = await productService.deleteProduct(id)

    res.status(200).json({
        message : "product deleted successfully",
        product
    })
}

let updateProduct = async(req,res)=>{
    let {id} = req.params
    let body = req.body

    let product = await productService.updateProduct(id,body);

    res.status(200).json({
        message : "product updated successfully",
        product
    })
}

module.exports = {addProduct,getProduct,deleteProduct,updateProduct}