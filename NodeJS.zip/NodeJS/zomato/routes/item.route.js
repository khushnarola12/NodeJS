let express = require("express")
const {itemController} = require("../controllers")
let route = express.Router()

route.get("/getItem",itemController.getItem)


route.post("/addItem",itemController.addItem)


route.put("/update/:id",itemController.update)

module.exports = route;