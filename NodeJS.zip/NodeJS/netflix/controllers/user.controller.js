const {userService} = require("../services")

let register = async(req,res)=>{
    let user= req.body;
    console.log(user);
    
    let email = user.email
    let imail = "khushnarola12@gmail.com"

    let password = user.password
    let pass = "khush123"

    let result = await userService.register(user);
    console.log(result);

    if(email==imail && password ==pass){
        console.log("you logged in successfully");
    }


    res.status(201).json({
        messsage : "user created succcessfully",
        result
    })
}

let getUser = async(req,res) =>{
    let result = await userService.getUser();

    res.status(200).json({
        message : "user get successfully",
        result,
    })
}

let deleteuser = async(req,res)=>{
    let {id}= req.params
    let user = await userService.deleteuser(id)

    res.status(200).json({
        message :"user deleted successfully",
        user
    })
  }
module.exports = {register,getUser,deleteuser}

