let express = require("express")
let routes = express.Router();

//user functionality
const user = require("../models/user.model")
let userRoute = require("./user.route")

//movie functionality
const movie = require("../models/movie.model")
let movieRoute = require("./movie.route")

routes.use("/user",userRoute)
routes.use("/movie",movieRoute)

module.exports = routes;