module.exports.userSchema = require("./user.model")
module.exports.itemSchema = require("./item.model")
module.exports.staffSchema = require("./staff.model")
module.exports.billSchema = require("./bill.model")

