const {dishSchema} = require("../models")

let addDish = (dish) =>{
    return dishSchema.create(dish)
}

let getDish = ()=>{
    return dishSchema.find()
}

let cateDish=()=>{
    return dishSchema.find({category:"thali"})
}

let update = (id,body) =>{
    return dishSchema.findByIdAndUpdate(id,body)
}
module.exports = {addDish,getDish,cateDish,update}