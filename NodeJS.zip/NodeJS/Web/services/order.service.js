const { orderSchema } = require("../models");

let addOrder = (body) => {
  return orderSchema.create(body);
};

let getOrder = () => {
  return orderSchema.find().populate("product").populate("user");
};

let getCart= (id)=>{
  return orderSchema.find({user:id}).populate("product").populate("user");
}
module.exports = { addOrder, getOrder,getCart };
