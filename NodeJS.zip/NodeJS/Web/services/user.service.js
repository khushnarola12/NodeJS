const { userSchema } = require("../models");
const user = require("../models/user.model");

let register = (user) => {
  return userSchema.create(user);
};

let getAllUser = () => {
  return userSchema.find();
};

let deleteUser = (id) => {
  return userSchema.findByIdAndDelete(id);
};

let updateUser = (id, body) => {
  return userSchema.findByIdAndUpdate(id, body);
};

module.exports = { register, getAllUser, deleteUser, updateUser };
