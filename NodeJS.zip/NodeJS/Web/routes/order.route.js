let express = require("express");
const { orderController } = require("../controllers");

let route = express.Router();

route.get("/get", orderController.getOrder);
route.post("/add", orderController.addOrder);
route.get("/getcart/:id",orderController.getCart)

module.exports = route;
