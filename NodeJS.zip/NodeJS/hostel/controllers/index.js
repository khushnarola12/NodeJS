module.exports.studentController = require("./student.controller")
module.exports.feeController = require("./fee.controller")
module.exports.trusteeController = require("./trustee.controller")