var http = require("http")
var path = require("path")
var express = require("express")
var bodyParser = require("body-parser")
var cors = require("cors")
const connectDB = require("./db/connectDB")
const routes = require("./routes")

var app = express()

app.use(express.json())
app.use(bodyParser.urlencoded({extended:false}))
app.use(
    cors({
        origin:"*"
    })
)

app.use("/v3",routes)

// database connection
connectDB()

http.createServer(app).listen(210,()=>{
    console.log("server started");
})

