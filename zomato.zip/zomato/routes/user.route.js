let express = require("express");
const {userController}= require("../controllers")
let route = express.Router();

route.get("/get",userController.getuser);

route.post("/register",userController.register);

route.delete("/delete/:id",userController.remove)

route.post("/login",userController.login)

module.exports= route;