let mongoose = require("mongoose")

let staffSchema = new mongoose.Schema({
    staffname :{
        type : String,
        required : true
    },

    gender :{
        type:String,
        required : true
    },

    mobileNo :{
        type:Number,
        required : true,
    },

    Age :{
        type:Number,
        required : true,
    }
})

let staff = mongoose.model("staffSchema",staffSchema);
module.exports = staff;