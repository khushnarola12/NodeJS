const {trusteeService} = require("../services")

let add = async(req,res) =>{
    let trustee = req.body
    console.log(trustee);

    let result = await trusteeService.add(trustee)
    console.log(result);

    res.status(201).json({
        message : "trustee added successfully",
        result
    })

}

let get = async(req,res)=>{
    let result = await trusteeService.get()
    
    res.status(200).json({
        message : "list",
        result
    })
}

let deleteTrustee = async(req,res)=>{
    let {id}=req.params
    let trustee = await trusteeService.deleteTrustee(id)

    res.status(200).json({
        message :"trustee deleted successfully",
        trustee
    })
}
module.exports = {add,get,deleteTrustee}