let express = require("express");
const user = require("../models/user.model");
const item = require("../models/item.model")
let routes = express.Router();
let userRoute = require("./user.route")
let itemRoute = require("./item.route")
let staffRoute = require("./staff.route")
let billRoute = require("./bill.route")
routes.use("/user",userRoute)

routes.use("/item",itemRoute)

routes.use("/staff",staffRoute)

routes.use("/bill",billRoute)
module.exports = routes;
