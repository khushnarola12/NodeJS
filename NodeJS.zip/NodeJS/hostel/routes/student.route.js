const {studentController} = require("../controllers")
let express = require("express")
let route = express.Router();

route.get("/getStudent",studentController.getStudent)

route.post("/addStudent",studentController.addStudent)

route.delete("/delete/:id",studentController.deleteStudent)

route.put("/update/:id",studentController.update)

module.exports = route;