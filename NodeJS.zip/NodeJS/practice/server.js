var http = require("http")
var path = require("path")
var express = require("express")
var cors = require("cors")
let bodyParser = require("body-parser");
var app = express();

app.use(express.json());

app.use(
    cors({
        origin:"*"
    })
)

app.use(bodyParser.urlencoded({extended: false})) 

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "./index.html"));
  });


app.get("/",(req,res)=>{
    res.sendFile(path.join(__dirname,"index.html"));
    res.status(200).json({message:"khush narola"})
})

app.post("/calc",(req,res)=>{
    let {num1,num2} = req.body;
    let sum = Number(num1) + Number(num2)
    // console.log(req.body);

    res.status(200).json({message:`the sum is ${sum}`});
})



http.createServer(app).listen(234,()=>{
    console.log("server started");
})