let mongoose = require("mongoose")

let itemSchema = new mongoose.Schema({
    itemName : {
        type : String,
        required : true,
    },

    category : {
        type : String,
        required : true,
    }
})

let item = mongoose.model("itemSchema",itemSchema);
module.exports = item