let express = require("express")
const {feeController}=require("../controllers")
let route = express.Router()

route.get("/get",feeController.get)

route.post("/payfee",feeController.payFee)

route.delete("/delete/:id",feeController.deleteFee)

module.exports = route