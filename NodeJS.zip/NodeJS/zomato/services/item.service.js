const {itemSchema} = require("../models")

let addItem = (item) => {
    return itemSchema.create(item)
}

let getItem = () =>{
    return itemSchema.find()
}

let update = (id,body)=>{
    return itemSchema.findByIdAndUpdate(id,body)
}

module.exports = {addItem,getItem,update};