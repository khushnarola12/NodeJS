const {userService} = require("../services")

let createUser = async(req,res)=>
{
    let user = req.body;
    console.log(user);

    let result = await userService.createUser(user);
    console.log(result);

    res.status(201).json({
        message:"user created successfully",
        result
    })
}

let getUser = async(req,res)=>{
    let result = await userService.getUser();

    res.status(200).json({
        message : "user get successfully",
        result
    })
}

let deleteUser = async(req,res)=>{
    let {id}=req.params
    let user=await userService.deleteUser(id)

    res.status(200).json({
        message :"user deleted successfully",
        user
    })
}
module.exports ={createUser,getUser,deleteUser}
