let express = require("express");
const {staffController} = require("../controllers")
let route = express.Router();

route.get("/getstaff",staffController.getAllStaff),
route.post("/register",staffController.register)


module.exports = route;