const {studentService} = require("../services")

let addStudent = async(req,res)=>{
    let student = req.body;
    console.log(student);
    
    var result = await studentService.addStudent(student);
    console.log(result);

    res.status(201).json({
        message : "student add successfully",
        result
        
    })

}

let getStudent = async(req,res)=>{
    let result = await studentService.getStudent()

    res.status(200).json({
        message : "Student get successfully",
        result
    })
}


let deleteStudent = async(req,res) =>{
    let {id}= req.params

    let student = await studentService.deleteStudent(id)

    res.status(200).json({
        message :"message deleted successfully",
        student
    })

}

let update = async(req,res)=>{
    let body = req.body
    let {id} = req.params

    let student = await studentService.update(id,body)

    res.status(200).json({
        message:"student updated successfully",
        student
    })
}

module.exports = {addStudent,getStudent,deleteStudent,update}

