var http = require("http")
var express = require("express")
var cors = require("cors")
var bodyParser = require("body-parser")
var path = require("path")
const connectDB = require("./db/connectDB")
const { connection } = require("mongoose")
const routes = require("./routes")
var app = express()


app.use(express.json())
app.use(
    cors({
        origin:"*"
    })
)

app.use("/hostel",routes)

// database connection
connectDB()

http.createServer(app).listen(3432,()=>{
    console.log("server started");
})