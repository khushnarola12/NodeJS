let mongoose = require("mongoose");

let orderSchema = new mongoose.Schema({
  product: {
    type: mongoose.Types.ObjectId,
    ref: "productSchema",
  },
  user: {
    type: mongoose.Types.ObjectId,
    ref: "userSchema",
  },
  date: {
    type: String,
  },
});

let order = mongoose.model("orderSchema", orderSchema);

module.exports = order;
