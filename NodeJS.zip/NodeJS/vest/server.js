let http = require("http");
let path = require("path");
let express = require("express");
let cors = require("cors");

let app = express();

app.use(express.json());
app.use(
  cors({
    origin: "*",
  })
);

app.get("/khush1", (req, res) => {
  res.status(200).json({ message: "khush narola" });
});

app.get("/khush123", (req, res) => {
  res.status(200).json({ message: "narola"});
});

http.createServer(app).listen(5800, () => {
  console.log("server started");
});
