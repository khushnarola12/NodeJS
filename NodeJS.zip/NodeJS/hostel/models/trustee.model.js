let mongoose = require("mongoose")

let trusteeSchema = new mongoose.Schema({
    name : {
        type: String,
        required : true
    },

    village :{
        type : String,
        required : true
    }
})

let trustee = mongoose.model("trusteeSchema",trusteeSchema)
module.exports = trustee