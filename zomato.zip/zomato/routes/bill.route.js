let express = require("express")
const {billController} = require("../controllers")
let route = express.Router()

route.get("/getbill",billController.getBill)

route.post("/create",billController.createBill)

module.exports = route