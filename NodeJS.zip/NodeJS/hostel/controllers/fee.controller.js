const {feeService} = require("../services")

let payFee = async(req,res) =>{
    let fee = req.body
    console.log(fee);

    let result = await feeService.payFee(fee)
    result

    res.status(201).json({
        message : "fees paid successfully",
        result
    })
}

let get = async(req,res)=>{
    let result = await feeService.get()

    res.status(200).json({
        message : "got bill",
        result
    })
}

let deleteFee = async(req,res)=>{
    let {id}= req.params
    let fee = await feeService.deleteFee(id)

    res.status(200).json({
        message :"fees deleted successfully",
        fee
    })
}

module.exports = {payFee,get,deleteFee}