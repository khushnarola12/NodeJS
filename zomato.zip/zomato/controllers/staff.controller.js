const {staffservice} = require("../services")

let register = async(req,res) =>{
    let staff = req.body;
    console.log(staff);

    let result = await staffservice.register(staff);
    console.log(result);

    res.status(201).json({
        message :"staff registered successfully",
        result
    })
}
let getAllStaff = async(req,res)=>{
    let result = await staffservice.getAllstaff();

    res.status(200).json({
        message:"staff get successfully",
        result
    })
}

module.exports = {register,getAllStaff}