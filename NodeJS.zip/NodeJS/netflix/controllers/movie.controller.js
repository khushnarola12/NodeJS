const { movieService } = require("../services");

let addMovie = async (req, res) => {
  let movie = req.body;
  console.log(movie);

  let result = await movieService.addMovie(movie);
  console.log(result);

  res.status(201).json({
    message: "movie added successfully",
    result,
  });
};

let getMovie = async (req, res) => {
  let result = await movieService.getMovie();

  res.status(200).json({
    message: "movie lists are",
    result,
  });
};

let getThriller = async (req, res) => {
//   console.log(req.params);

//   let catgory = req.params;
  let result = await movieService.getThriller();

  res.status(200).json({
    message: "movie get successfully",
    result,
  });
};

let update = async(req,res) =>{
  let body = req.body
  let {id} = req.params
  
  let movie = await movieService.update(id,body)

  res.status(200).json({
    message : "movie updated successfully",
    movie

  })
}

module.exports = { addMovie, getMovie, getThriller,update };
