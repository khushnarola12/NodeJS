let express = require("express")
const {trusteeController} = require("../controllers")
let route = express.Router()


route.get("/get",trusteeController.get)

route.post("/add",trusteeController.add)

route.delete("/delete/:id",trusteeController.deleteTrustee)

module.exports = route