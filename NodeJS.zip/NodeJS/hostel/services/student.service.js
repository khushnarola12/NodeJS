const {studentSchema} = require("../models")
const student = require("../models/student.model")

let addStudent = (student) =>{
    return studentSchema.create(student)
}

let getStudent = () =>{
    return studentSchema.find()
}

let deleteStudent = (id)=>{
    return studentSchema.findByIdAndDelete(id)
}

let update = (id,body)=>{
    return studentSchema.findByIdAndUpdate(id,body)
}
module.exports = {addStudent,getStudent,deleteStudent,update}