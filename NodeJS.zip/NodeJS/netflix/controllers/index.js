module.exports.userController = require("./user.controller")
module.exports.movieController = require("./movie.controller")