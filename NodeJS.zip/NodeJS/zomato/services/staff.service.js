const {staffSchema} = require("../models");


let register = (staff)=>{
    return staffSchema.create(staff);
}

let getAllstaff = () =>{
    return staffSchema.find()
}

module.exports = {register,getAllstaff};
