const { userSchema } = require("../models");

let register = (user) => {
  return userSchema.create(user);
};

let getAlluser = () => {
  return userSchema.find();
};

let remove = (id) => {
  return userSchema.findByIdAndDelete(id);
};

let login = (email) => {
  return userSchema.findOne({ email: email });
};

module.exports = { register, getAlluser, remove, login };
