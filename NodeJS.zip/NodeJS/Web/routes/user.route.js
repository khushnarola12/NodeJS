let express = require("express");
const { userController } = require("../controllers");
let route = express.Router();

route.get("/get", userController.getUser);

route.post("/register", userController.register);

route.delete("/delete/:id", userController.deleteUser);


route.put('/update/:id',userController.updateUser)

module.exports = route;
