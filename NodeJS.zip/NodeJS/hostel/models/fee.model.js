let mongoose = require("mongoose")

let feeSchema = new mongoose.Schema({
    studentName : {
        type : String,
        required : true
    },

    amount : {
        type:String,
        required : true
    }
})

let fee = mongoose.model("feeSchema",feeSchema)
module.exports = fee
