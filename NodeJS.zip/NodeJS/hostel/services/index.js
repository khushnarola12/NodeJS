module.exports.studentService = require("./student.service")
module.exports.feeService = require("./fee.service")
module.exports.trusteeService = require("./trustee.service")