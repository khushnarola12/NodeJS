const {billSchema} = require("../models")

let createBill = (bill) =>{
    return billSchema.create(bill)
}

let getBill = () =>{
    return billSchema.find()
}

module.exports = {createBill,getBill}