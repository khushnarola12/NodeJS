let express = require("express")
let routes = express.Router()


const student = require("../models/student.model")
let studentRoute = require("./student.route")

const fee = require("../models/fee.model")
let feeRoute = require("./fee.route")

const trustee = require("../models/trustee.model")
let trusteeRoute = require("./trustee.route")


routes.use("/student",studentRoute)
routes.use("/fee",feeRoute)
routes.use("/trustee",trusteeRoute)


module.exports = routes