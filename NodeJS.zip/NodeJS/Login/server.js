var http = require("http");
var path = require("path");
var express = require("express");
var bodyParser = require("body-parser");
var cors = require("cors");

var app = express();
app.use(
  cors({
    origin: "*",
  })
);

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "./index.html"));
});

app.post("/regis", (req, res) => {
  console.log(req.body);
});

http.createServer(app).listen(2312, () => {
  console.log("server started");
});
