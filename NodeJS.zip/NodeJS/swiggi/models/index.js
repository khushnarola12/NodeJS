module.exports.userSchema = require("./user.model")
module.exports.dishSchema = require("./dish.model")