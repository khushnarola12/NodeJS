const mongoose = require("mongoose");

let productSchmea = new mongoose.Schema({
  productName: {
    type: String,
    required: true,
  },

  price: {
    type: Number,
    required: true,
  },
});

let product = mongoose.model("productSchema", productSchmea);

module.exports = product;
