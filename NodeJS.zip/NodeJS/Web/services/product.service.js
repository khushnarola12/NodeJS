const {productSchema} = require("../models")

let addProduct = (product) =>{
    return productSchema.create(product)
}

let getProduct = () =>{
    return productSchema.find()
}

let deleteProduct = (id) =>{
    return productSchema.findByIdAndDelete(id)
}

let updateProduct = (id,body) =>{
    return productSchema.findByIdAndUpdate(id,body)
}
module.exports = {addProduct,getProduct,deleteProduct,updateProduct}