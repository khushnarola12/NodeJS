const {userSchema} = require("../models")

let register = (user)=>{
    return userSchema.create(user);
}

let getUser = ()=>{
    return userSchema.find();
}

let deleteuser = (id) =>{
    return userSchema.findByIdAndDelete(id)
}

module.exports = {register,getUser,deleteuser}