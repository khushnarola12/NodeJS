let express = require("express");
const {userController}= require("../controllers")
let route = express.Router();

route.get("/get",userController.getUser);

route.post("/register",userController.createUser);

route.delete("/delete/:id",userController.deleteUser)

module.exports= route