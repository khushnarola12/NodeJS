var mongoose = require("mongoose")

connectDB = () =>{
    mongoose
    .connect("mongodb://localhost:27017/hostel")
    .then(()=>{
        console.log("Database connected");
    })
    .catch((err)=>{
        console.log(err);
    })
}

module.exports = connectDB;