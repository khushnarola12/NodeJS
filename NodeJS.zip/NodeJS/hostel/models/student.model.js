let mongoose = require("mongoose")

let studentSchema = new mongoose.Schema({
    studentName : {
        type : String,
        required : true
    },

    Age : {
        type : String,
        required : true
    },

    city : {
        type : String,
        required : true
    },

    course : {
        type :String,
        required : true
    }
})

let student = mongoose.model("studentSchema",studentSchema)
module.exports = student;