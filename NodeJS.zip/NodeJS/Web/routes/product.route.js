let express = require("express")
const {productController }= require("../controllers")
let route = express.Router()

route.get("/get",productController.getProduct)
route.post("/add",productController.addProduct)
route.delete("/delete/:id",productController.deleteProduct)
route.put("/update/:id",productController.updateProduct)

module.exports = route