const user = require("../models/user.model");
const { orderService } = require("../services");

let addOrder = async (req, res) => {
  console.log(req.body);

  let body = req.body;

  let order = await orderService.addOrder(body);

  res.status(200).json({
    message: "order created success",
    order,
  });
};

let getOrder = async (req, res) => {
  let order = await orderService.getOrder();

  res.status(200).json({
    message: "order get success",
    order,
  });
};

let getCart = async(req,res)=>{
  let {id} = req.params
  console.log(id);
  let cart = await orderService.getCart(id)
  console.log(cart);
 

  res.status(200).json({
    message:"cart get successfully",
    cart
  })
}
module.exports = { addOrder, getOrder,getCart };
