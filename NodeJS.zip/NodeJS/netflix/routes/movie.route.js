var express = require("express")
const {movieController} = require("../controllers")
let route = express.Router()


route.get("/getlist",movieController.getMovie)

route.post("/addmovie",movieController.addMovie);

route.get("/:category",movieController.getThriller)

route.put("/update/:id",movieController.update)

module.exports = route;