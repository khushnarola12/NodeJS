const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true, // Use `true` for port 465, `false` for all other ports
  auth: {
    user: "khushnarola09@gmail.com",
    pass: "fwyl xuwtwnvgzxfu",
  },
});


let sendEmail = async(to,subject,data)=>{
    return await transporter.sendMail({
        from: '"Zomato👻" <khushnarola08@gmail.com>', // sender address
        to: to, // list of receivers
        subject: subject, // Subject line
        text: data, // plain text body
        // html: "<b>Hello world?</b>", // html body
      });
}

module.exports = sendEmail