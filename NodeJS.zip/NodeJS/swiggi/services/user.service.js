const {userSchema} = require("../models")

let createUser = (user) =>{
    return userSchema.create(user)
} 

let getUser = () =>{
    return userSchema.find()
}

let deleteUser = (id)=>{
    return userSchema.findByIdAndDelete(id)
}
module.exports = {createUser,getUser,deleteUser}