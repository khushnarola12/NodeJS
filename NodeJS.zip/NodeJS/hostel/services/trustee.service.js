const {trusteeSchema} = require("../models")
const trustee = require("../models/trustee.model")

let add = (trustee) =>{
    return trusteeSchema.create(trustee)
}

let get = ()=>{
    return trusteeSchema.find()
}

let deleteTrustee =(id) =>{
    return trusteeSchema.findByIdAndDelete(id)
}
module.exports = {add,get,deleteTrustee}